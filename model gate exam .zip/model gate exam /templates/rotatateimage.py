def ri():
	for i in range(0,3):
		for j in range(0,3):
			for k in range(0,3):
				print(i,j)
print(ri())