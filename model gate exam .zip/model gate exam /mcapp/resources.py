from import_export import resources
from .models import questions,e_marks

class e_marksResource(resources.ModelResource):

    class Meta:
        model = e_marks
        #fields = ('id','u_name','stu_name','stu_id','r_num','total_marks')

class questionsResource(resources.ModelResource):

    class Meta:
        model = questions