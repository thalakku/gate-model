from django.db import models
from django.contrib.auth.models import User
from django.conf import settings
from django.db import models
# Create your models here.
questions_type=(
	("2_mark","2_mark"),
	("1_mark","1_mark"),
	("NAT","NAT")
	)
questions_option=(
	("1","1"),
	("2","2"),
	("3","3"),
	("4","4")
	)
class students_details(models.Model):
	stu_name = models.CharField(max_length=100)
	dept = models.TextField()
	reg_num = models.CharField(max_length=100)
	year = models.IntegerField()
	def __str__(self):
		return self.id
class e_marks(models.Model):
	u_name= models.CharField(max_length=100)
	stu_name=models.CharField(max_length=100,default='',null=True,blank=True)
	stu_id=models.CharField(max_length=100,default='',null=True,blank=True)
	r_num = models.CharField(max_length=100)
	total_marks = models.CharField(max_length=100,default='')
	def __str__(self):
		return self.u_name
class questions(models.Model):
	id = models.AutoField(primary_key=True,)
	question_no=models.CharField(max_length=3,default='',null=True)
	question_type=models.CharField(max_length=100,choices=questions_type,default='1_mark')
	questions= models.CharField(max_length=1000,default='',null=True)
	question_image=models.ImageField(upload_to='images/',default='',null=True,blank=True)
	option_1 = models.CharField(max_length=100,default='',null=True,blank=True)
	option_2 = models.CharField(max_length=100,default='',null=True,blank=True)
	option_3 = models.CharField(max_length=100,default='',null=True,blank=True)
	option_4 = models.CharField(max_length=100,default='',null=True,blank=True)
	correct_option=models.CharField(max_length=3,default='',choices=questions_option,null=True,blank=True)
	correct_answer_for_NAT =models.CharField(max_length=30,default='',null=True,blank=True)
	img_op1=models.ImageField(upload_to='images/',default='',null=True,blank=True)
	img_op2=models.ImageField(upload_to='images/',default='',null=True,blank=True)
	img_op3=models.ImageField(upload_to='images/',default='',null=True,blank=True)
	img_op4=models.ImageField(upload_to='images/',default='',null=True,blank=True)
	def __str__(self):
		return self.question_no
class answers(models.Model):
	u_id = models.CharField(max_length=100)
	arranged_order=models.CharField(max_length=100)
	q_id = models.CharField(max_length=100)
	rq_id = models.CharField(max_length=100,default='')
	tem_ans=models.CharField(max_length=100,default='',null=True)
	saved_ans=models.CharField(max_length=100,default='',null=True,blank=True) 
	def __str__(self):
		return self.id