from django.http import HttpResponse,HttpResponseRedirect
from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
from django.contrib import messages
from .models import students_details,e_marks,questions,answers
from django.core.exceptions import ObjectDoesNotExist
from django.db.models import Q
from django import template
from tablib import Dataset
from .resources import e_marksResource
import datetime
from django.http import HttpResponse
# Create your views here.
def import_data(request):
    if request.method == 'POST':
        file_format = request.POST['file-format']
        employee_resource = EmployeeResource()
        dataset = Dataset()
        new_employees = request.FILES['importData']

        if file_format == 'CSV':
            imported_data = dataset.load(new_employees.read().decode('utf-8'),format='csv')
            result = employee_resource.import_data(dataset, dry_run=True)                                                                 
        elif file_format == 'JSON':
            imported_data = dataset.load(new_employees.read().decode('utf-8'),format='json')
            # Testing data import
            result = employee_resource.import_data(dataset, dry_run=True) 

        if not result.has_errors():
            # Import now
            employee_resource.import_data(dataset, dry_run=False)

    return render(request, 'import.html')    
def export_data(request):
    if request.method == 'POST':
        # Get selected option from form
        file_format = request.POST['file-format']
        employee_resource = EmployeeResource()
        dataset = employee_resource.export()
        if file_format == 'CSV':
            response = HttpResponse(dataset.csv, content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="exported_data.csv"'
            return response        
        elif file_format == 'JSON':
            response = HttpResponse(dataset.json, content_type='application/json')
            response['Content-Disposition'] = 'attachment; filename="exported_data.json"'
            return response
        elif file_format == 'XLS (Excel)':
            response = HttpResponse(dataset.xls, content_type='application/vnd.ms-excel')
            response['Content-Disposition'] = 'attachment; filename="exported_data.xls"'
            return response   

    return render(request, 'export.html')
stu_det=students_details.objects.all()

def result(request): 
	#request.SESSION_EXPIRE_SECONDS
	request.session.session_key
	current_user=request.user
	user_answers=answers.objects.filter(u_id=current_user.id)
	total_mark=0
	
	for i in user_answers:
		#print(i.rq_id)
		oq_id_rq_id=questions.objects.get(id=int(i.rq_id))
		q_type=oq_id_rq_id.question_type
		c_ans=oq_id_rq_id.correct_option
		c_ans_for_nat=oq_id_rq_id.correct_answer_for_NAT
		#print(q_type)
		#print(c_ans)
		#print(i.saved_ans)
		if q_type == "1_mark":
			if c_ans == i.saved_ans:
				total_mark=total_mark+1
				#print("crt for 1_mark")
			elif i.saved_ans == None:
				#print("none in 1_mark")
				total_mark=total_mark
			elif i.saved_ans == "":
				#print(" qu'' in 1_mark ")
				total_mark=total_mark
			else:
				print("wrong_ans_1mark")
				total_mark=total_mark-1.3
		elif q_type == "2_mark":
			if c_ans == i.saved_ans:
				total_mark=total_mark+2
			elif i.saved_ans == None:
				total_mark=total_mark
			elif i.saved_ans == "":
				total_mark=total_mark
			else:
				total_mark=total_mark-2.3
		elif q_type == "NAT":
			if c_ans_for_nat == i.saved_ans:
				total_mark=total_mark+1
			elif i.saved_ans == None:
				total_mark=total_mark
			else:
				total_mark=total_mark
	e_m=e_marks.objects.get(u_name=current_user)
	e_m.total_marks=total_mark
	e_m.save()

	return render(request,'result.html',{'total_mark':total_mark,'current_user':current_user})


def logout(request):
	auth.logout(request)
	return redirect('home')
def regnopage(request):
	#request.SESSION_EXPIRE_SECONDS
	current_datetime = datetime.datetime.now()
	ques=questions.objects.all()
	l=[]
	for i in range(0,len(ques)):
		l.append(ques[i].id)
	l.sort()
	#print(l)
	stu_det=students_details.objects.all()
	current_user=request.user
	answers_for_button=questions.objects.all()
	c_option=answers.objects.get(u_id=current_user.id,q_id=l[0])
	r_id=c_option.rq_id
	#print(current_user.id)
	ques_info=questions.objects.get(id=int(r_id))
	ques_type=ques_info.question_type
	#print(ques_type)
	ques_img=ques_info.question_image
	question=ques_info.questions
	option_1=ques_info.option_1
	img_option_1=ques_info.img_op1
	option_2=ques_info.option_2
	img_option_2=ques_info.img_op2
	option_3=ques_info.option_3
	img_option_3=ques_info.img_op3
	option_4=ques_info.option_4
	img_option_4=ques_info.img_op4
	ques_id=c_option.q_id
	ques_no=c_option.arranged_order
	#ques_id_ordered=ques.
	#print(img_option_4,"img")
	cheacked_option=""
	for i in range(0,len(l)):
		#print(i.questions)
		if str(l[i]) in request.POST:
			c_option=answers.objects.get(u_id=current_user.id,q_id=l[i])
			r_id=c_option.rq_id
			ques_info=questions.objects.get(id=int(r_id))

			ques_type=ques_info.question_type

			#print(ques_type)
			ques_img=ques_info.question_image
			question=ques_info.questions
			option_1=ques_info.option_1
			img_option_1=ques_info.img_op1
			option_2=ques_info.option_2
			img_option_2=ques_info.img_op2
			option_3=ques_info.option_3
			img_option_3=ques_info.img_op3
			option_4=ques_info.option_4
			img_option_4=ques_info.img_op4
			ques_id=c_option.q_id
			ques_no=c_option.arranged_order
			cheacked_option=c_option.tem_ans


		elif "n "+str(l[i]) in request.POST:
			if l[i]==l[-1]:
				c_option=answers.objects.get(u_id=current_user.id,q_id=l[i])
				r_id=c_option.rq_id
				ques_info=questions.objects.get(id=int(r_id))

				ques_type=ques_info.question_type
				ques_img=ques_info.question_image
				question=ques_info.questions
				option_1=ques_info.option_1
				img_option_1=ques_info.img_op1
				option_2=ques_info.option_2
				img_option_2=ques_info.img_op2
				option_3=ques_info.option_3
				img_option_3=ques_info.img_op3
				option_4=ques_info.option_4
				img_option_4=ques_info.img_op4
				ques_id=c_option.q_id
				ques_no=c_option.arranged_order	
				cheacked_option=c_option.tem_ans
			else:
				c_option=answers.objects.get(u_id=current_user.id,q_id=l[i+1])
				r_id=c_option.rq_id
				ques_info=questions.objects.get(id=int(r_id))

				ques_type=ques_info.question_type
				ques_img=ques_info.question_image
				question=ques_info.questions
				option_1=ques_info.option_1
				img_option_1=ques_info.img_op1
				option_2=ques_info.option_2
				img_option_2=ques_info.img_op2
				option_3=ques_info.option_3
				img_option_3=ques_info.img_op3
				option_4=ques_info.option_4
				img_option_4=ques_info.img_op4
				ques_id=c_option.q_id
				ques_no=c_option.arranged_order	
				cheacked_option=c_option.tem_ans	
		elif "p "+str(l[i]) in request.POST:
			#print(i)
			if l[i]==l[0]:
				c_option=answers.objects.get(u_id=current_user.id,q_id=l[i])
				r_id=c_option.rq_id
				ques_info=questions.objects.get(id=int(r_id))

				ques_type=ques_info.question_type
				ques_img=ques_info.question_image
				question=ques_info.questions
				option_1=ques_info.option_1
				img_option_1=ques_info.img_op1
				option_2=ques_info.option_2
				img_option_2=ques_info.img_op2
				option_3=ques_info.option_3
				img_option_3=ques_info.img_op3
				option_4=ques_info.option_4
				img_option_4=ques_info.img_op4
				ques_id=c_option.q_id
				ques_no=c_option.arranged_order
				cheacked_option=c_option.tem_ans
			else:
				c_option=answers.objects.get(u_id=current_user.id,q_id=l[i-1])
				r_id=c_option.rq_id
				ques_info=questions.objects.get(id=int(r_id))

				ques_type=ques_info.question_type		
				ques_img=ques_info.question_image
				question=ques_info.questions
				option_1=ques_info.option_1
				img_option_1=ques_info.img_op1
				option_2=ques_info.option_2
				img_option_2=ques_info.img_op2
				option_3=ques_info.option_3
				img_option_3=ques_info.img_op3
				option_4=ques_info.option_4
				img_option_4=ques_info.img_op4
				ques_id=c_option.q_id
				ques_no=c_option.arranged_order	
				cheacked_option=c_option.tem_ans
		elif "S&N "+str(l[i]) in request.POST:

			#print(i)
			if l[i]==l[-1]:
				c_option=answers.objects.get(u_id=current_user.id,q_id=l[0])
				r_id=c_option.rq_id
				ques_info=questions.objects.get(id=int(r_id))
		
				ques_type=ques_info.question_type
				ques_img=ques_info.question_image
				question=ques_info.questions
				option_1=ques_info.option_1
				img_option_1=ques_info.img_op1
				option_2=ques_info.option_2
				img_option_2=ques_info.img_op2
				option_3=ques_info.option_3
				img_option_3=ques_info.img_op3
				option_4=ques_info.option_4
				img_option_4=ques_info.img_op4
				ques_id=c_option.q_id
				ques_no=c_option.arranged_order
				#print(cheacked_option)

				option_v = request.POST.get('option_v')
				t_ans=answers.objects.get(u_id=current_user.id,q_id=l[i])
				if "nat "+str(l[i]) in request.POST:
					NAT_answer = request.POST.get("nat "+str(l[i]))
					t_ans.tem_ans=NAT_answer
					t_ans.saved_ans=NAT_answer
					t_ans.save()
				else:
					t_ans.tem_ans=str(option_v)
					t_ans.saved_ans=str(option_v)
					t_ans.save()
				cheacked_option=c_option.tem_ans
			else:
				c_option=answers.objects.get(u_id=current_user.id,q_id=l[i+1])
				r_id=c_option.rq_id
				ques_info=questions.objects.get(id=int(r_id))
		
				ques_type=ques_info.question_type
				ques_img=ques_info.question_image
				question=ques_info.questions
				option_1=ques_info.option_1
				img_option_1=ques_info.img_op1
				option_2=ques_info.option_2
				img_option_2=ques_info.img_op2
				option_3=ques_info.option_3
				img_option_3=ques_info.img_op3
				option_4=ques_info.option_4
				img_option_4=ques_info.img_op4
				ques_id=c_option.q_id


				ques_no=c_option.arranged_order
				cheacked_option=c_option.tem_ans
				option_v = request.POST.get('option_v')
				t_ans=answers.objects.get(u_id=current_user.id,q_id=l[i])
				if "nat "+str(l[i]) in request.POST:
					NAT_answer = request.POST.get("nat "+str(l[i]))
					t_ans.tem_ans=NAT_answer
					t_ans.saved_ans=NAT_answer
					t_ans.save()
				else:
					t_ans.tem_ans=str(option_v)
					t_ans.saved_ans=str(option_v)
					t_ans.save()
		elif "cr "+str(l[i]) in request.POST:
			c_option=answers.objects.get(u_id=current_user.id,q_id=l[i])
			r_id=c_option.rq_id
			ques_info=questions.objects.get(id=int(r_id))
	
			ques_type=ques_info.question_type
			ques_img=ques_info.question_image
			question=ques_info.questions
			option_1=ques_info.option_1
			img_option_1=ques_info.img_op1
			option_2=ques_info.option_2
			img_option_2=ques_info.img_op2
			option_3=ques_info.option_3
			img_option_3=ques_info.img_op3
			option_4=ques_info.option_4
			img_option_4=ques_info.img_op4
			ques_id=c_option.q_id
			ques_no=c_option.arranged_order
			t_ans=answers.objects.get(u_id=current_user.id,q_id=l[i])
			t_ans.tem_ans=""
			t_ans.saved_ans=""
			t_ans.save()
		elif "mfr "+str(ques[i].id) in request.POST:
			c_option=answers.objects.get(u_id=current_user.id,q_id=l[i])
			r_id=c_option.rq_id
			ques_info=questions.objects.get(id=int(r_id))
		
			ques_type=ques_info.question_type
			ques_img=ques_info.question_image
			question=ques_info.questions
			option_1=ques_info.option_1
			img_option_1=ques_info.img_op1
			option_2=ques_info.option_2
			img_option_2=ques_info.img_op2
			option_3=ques_info.option_3
			img_option_3=ques_info.img_op3
			option_4=ques_info.option_4
			img_option_4=ques_info.img_op4
			ques_id=c_option.q_id
			ques_no=c_option.arranged_order
			#print(cheacked_option)
			option_v = request.POST.get('option_v')
			t_ans=answers.objects.get(u_id=current_user.id,q_id=l[i])
			if "nat "+str(l[i]) in request.POST:
				NAT_answer = request.POST.get("nat "+str(l[i]))
				t_ans.tem_ans=NAT_answer
				t_ans.saved_ans=NAT_answer
				t_ans.save()
			else:
				t_ans.tem_ans=str(option_v)
				t_ans.saved_ans=str(option_v)
				t_ans.save()
			c_op=answers.objects.get(u_id=current_user.id,q_id=l[i])
			cheacked_option=c_op.tem_ans


	return render(request,'regnopage.html',{'current_datetime':current_datetime,'ques_type':ques_type,'img_option_2':img_option_2,'img_option_3':img_option_3,'img_option_4':img_option_4,'img_option_1':img_option_1,'ques_img':ques_img,'ques_no':ques_no,'answers_for_button':answers_for_button,'cheacked_option':cheacked_option,'ques_id':ques_id,'ques':ques,'question':question,'option_1':option_1,'option_2':option_2,'option_3':option_3,'option_4':option_4,'stu_det':stu_det})
def home(request):
	if request.method=='POST':
		user_name=request.POST['user_name']
		password=request.POST['password']
		user = auth.authenticate(username=user_name,password=password)
		if user is not None:
			auth.login(request,user)
			return redirect('instructions')
		else:
			messages.info(request,'invalid login')
			return redirect('home')
	else:
		return render(request,'home.html')
def register(request):

	if request.method == 'POST':
		regno = request.POST['regno']
		first_name = request.POST['first_name']
		last_name = request.POST['last_name']
		user_name = request.POST['user_name']
		password1 = request.POST['password1']
		password2 = request.POST['password2']		
		email = request.POST['email']
		if password1==password2:
			if User.objects.filter(username=user_name).exists():
				messages.info(request,'user name taken try different')
				return redirect('register')
			elif User.objects.filter(email=email).exists():
				messages.info(request,'enter valid email')
				return redirect('register')
			elif not students_details.objects.filter(reg_num=regno).exists():
				messages.info(request,'you are not permited only nscet students permited')
				return redirect('register')
			elif e_marks.objects.filter(r_num=regno).exists():
				messages.info(request,'already you have an account')
				return redirect('register')	
			else:
				user = User.objects.create_user(username=user_name,password=password1,email=email,first_name=first_name,last_name=last_name)
				user.save()
				e_marksobj=e_marks(r_num=regno,u_name=user_name)
				e_marksobj.save()
				return render(request,'home.html')
		else:
			messages.info(request,'password taker')
			return redirect('register')
	else:
		return render(request,'register.html')
def instructions(request):
	current_user=request.user
	ques=questions.objects.all().order_by("?")
	ans=answers.objects.all()
	if not answers.objects.filter(u_id=current_user.id).exists():
		l=[]
		for i in range(0,len(ques)):
			l.append(ques[i].id)
		l.sort()
		for i in range(0,len(ques)):
			r_ans=answers(u_id=str(current_user.id),q_id=str(l[i]),rq_id=str(ques[i].id),arranged_order=i+1)
			r_ans.save()
	if "agree" in request.POST:
		return redirect("regnopage")
	return render(request,'instructions.html')