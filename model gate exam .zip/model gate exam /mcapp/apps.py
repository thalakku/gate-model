from django.apps import AppConfig


class McappConfig(AppConfig):
    name = 'mcapp'
