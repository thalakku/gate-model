from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('logout',views.logout, name='logout'),
    path('home', views.home, name='home'),
    path('register',views.register, name='register'),
    path('regnopage',views.regnopage, name='regnopage'),
    path('instructions',views.instructions, name='instructions'),
    path('result',views.result, name='result')

] 