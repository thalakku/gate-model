from django.contrib import admin
from django.contrib.auth.models import User,auth
from mcapp.models import students_details,questions,answers,e_marks
from import_export.admin import ImportExportModelAdmin

# Register your models here.
admin.site.register(students_details)
admin.site.register(questions)
admin.site.register(answers)
admin.site.register(e_marks)
class e_marksAdmin(ImportExportModelAdmin):
	#list_display =('id','u_name','stu_name','stu_id','r_num','total_marks')
	pass
class questionsAdmin(ImportExportModelAdmin):
	#list_display =('id','u_name','stu_name','stu_id','r_num','total_marks')
	pass
admin.site.unregister(e_marks)
admin.site.register(e_marks, e_marksAdmin)
admin.site.unregister(questions)
admin.site.register(questions, questionsAdmin)